#include "defs/esnl_pub.h"

#include "timer.h"

	
void timer::start()
{
}


void timer::stop()
{
}
